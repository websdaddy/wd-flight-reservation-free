document.addEventListener('DOMContentLoaded', function () {
    if (!document.getElementById('wd-search-flight')) return;

    Vue.component('v-select', VueSelect.VueSelect);

    new Vue({
        el: '#wd-search-flight',
        data: {
            legs: [{ from: null, to: null, date: '', pax: 1 }],
            requirements_visibility: false,
            requirements: '',
            options: [],
            loading: false,
            searchTimer: null,
            flatpickrs: []
        },
        computed: {
            isSearchDisabled() {
                return !this.legs.every(leg => leg.from && leg.to && leg.from.iata_code !== leg.to.iata_code && leg.date && leg.pax >= 1);
            }
        },
        methods: {
            async searchAirports(search, loading) {
                if (!search || search.length < 2) {
                    this.options = [];
                    return;
                }
                loading(true);
                this.loading = true;
                clearTimeout(this.searchTimer);
                this.searchTimer = setTimeout(async () => {
                    try {
                        const res = await fetch(`${wdFlight.restUrl}?q=${encodeURIComponent(search)}`);
                        if (!res.ok) throw new Error('API error');
                        const data = await res.json();

                        const formatted = [];
                        data.forEach(group => {
                            const country_name = group.country_name || 'Other airports';
                            const iso2 = group.iso2 || 'xx';
                            formatted.push({ label: country_name, iso2: iso2, disabled: true });
                            group.airports.forEach(a => {
                                formatted.push({
                                    label: `${a.city || 'Unknown city'} (${a.iata_code || '???'})`,
                                    city: a.city,
                                    iata_code: a.iata_code,
                                    icao_code: a.icao_code,
                                    name: a.name,
                                    iso2: iso2,
                                    country_name: country_name,
                                    disabled: false
                                });
                            });
                        });
                        this.options = formatted;
                    } catch (e) {
                        console.error(e);
                        this.options = [];
                    }
                    loading(false);
                    this.loading = false;
                }, 250);
            },
            flagUrl(iso2) {
                return iso2 && iso2 !== 'xx'
                    ? `${wdFlight.flagsUrl}${iso2.toLowerCase()}.svg`
                    : `${wdFlight.flagsUrl}xx.svg`;
            },
            initFlatpickr(index) {
                const input = this.$refs[`date_${index}`][0];
                if (!input) return;
                flatpickr(input, {
                    enableTime: true,
                    dateFormat: "Y-m-d H:i",
                    altInput: true,
                    altFormat: "j F Y, h:i K",
                    time_24hr: false,
                    minDate: "today",
                    onChange: (selectedDates, dateStr) => {
                        this.legs[index].date = dateStr;
                    }
                });
            },
            searchFlights() {
                if (this.isSearchDisabled) return;
                const leg = this.legs[0];
                const flight_info = `${leg.from.iata_code} | ${leg.from.name} | ${leg.from.city}, ${leg.from.iso2.toUpperCase()} >>> ${leg.to.iata_code} | ${leg.to.name} | ${leg.to.city}, ${leg.to.iso2.toUpperCase()} | ${leg.date} | PAX: ${leg.pax}`;

                const params = new URLSearchParams();
                params.set('flight_info', flight_info);
                if (this.requirements_visibility && this.requirements) {
                    params.set('requirements', this.requirements);
                }
                window.location.href = `${wdFlight.bookingPage}?${params.toString()}`;
            }
        },
        mounted() {
            this.$nextTick(() => this.legs.forEach((_, i) => this.initFlatpickr(i)));
        },
        template: `<form class="xtd-search-flight" @submit.prevent="searchFlights">...</form>` // full template same as before
    });
});
