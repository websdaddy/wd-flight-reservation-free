<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class WD_Flight_Reservation {
    private $airports_file;
    private $countries_file;
    public function __construct() {
        $this->airports_file = plugin_dir_path(__FILE__) . 'data/airports.csv';
        $this->countries_file = plugin_dir_path(__FILE__) . 'data/countries.csv';
        register_activation_hook( __FILE__, [ $this, 'plugin_install' ] );
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
        add_shortcode( 'wd-flight-search', [ $this, 'render_search_shortcode' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
    }
	public function enqueue_scripts() {
        wp_enqueue_style( 'wd-flight-css', plugin_dir_url(__FILE__) . 'assets/css/flight.css', [], '1.3' );
        wp_enqueue_style( 'v-select-css', plugin_dir_url(__FILE__) . 'assets/css/vue-select.css' );
        wp_enqueue_style( 'flatpickr-css', plugin_dir_url(__FILE__) . 'assets/css/flatpickr.min.css' );
        wp_enqueue_style( 'font-awesome', plugin_dir_url(__FILE__) . 'assets/css/all.min.css' );
        wp_enqueue_script( 'vue', plugin_dir_url(__FILE__) . 'assets/js/vue.js', [], null, true );
        wp_enqueue_script( 'v-select',  plugin_dir_url(__FILE__) . 'assets/js/vue-select.js', ['vue'], null, true );
        wp_enqueue_script( 'flatpickr', plugin_dir_url(__FILE__) . 'assets/js/flatpickr.min.js', [], null, true );
        wp_enqueue_script( 'wd-flight-js', plugin_dir_url(__FILE__) . 'assets/js/flight-search.js', ['vue','v-select','flatpickr'], '1.3', true );
        wp_localize_script( 'wd-flight-js', 'wdFlight', [
            'restUrl' => esc_url_raw( get_rest_url( null, 'wd-flight/v1/airports' ) )
        ] );
    }
    public function plugin_install() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $airports_table = $wpdb->prefix . 'wd_airports';
        $wpdb->query("DROP TABLE IF EXISTS $airports_table");
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta("
            CREATE TABLE $airports_table (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL,
                city VARCHAR(255),
                iata_code CHAR(3),
                icao_code VARCHAR(10),
                latitude DOUBLE,
                longitude DOUBLE,
                country_name VARCHAR(255),
                iso2 CHAR(2),
                PRIMARY KEY (id),
                UNIQUE KEY `icao_code` (`icao_code`),
                KEY `iso2` (`iso2`),
                KEY `iata` (`iata_code`),
                KEY `city` (`city`)
            ) $charset_collate;
        ");
        $countries = $this->parse_csv( $this->countries_file );
        $country_map = [];
        foreach ( $countries as $c ) {
            $iso2 = strtolower( trim($c['code'] ?? '') );
            $cname = trim($c['name'] ?? '');
            if ( $iso2 && $cname ) $country_map[$iso2] = $cname;
        }
        $airports = $this->parse_csv( $this->airports_file );
        foreach ( $airports as $a ) {
            $iso2 = strtolower( trim($a['iso_country'] ?? '') );
            if ( !$iso2 or strlen($a['iata_code'])<3) continue;
            $wpdb->replace( $airports_table, [
                'name' => $a['name'] ?? '',
                'city' => $a['municipality'] ?? '',
                'iata_code' => $a['iata_code'] ?? '',
                'icao_code' => $a['ident'] ?? '',
                'latitude' => floatval($a['latitude_deg'] ?? 0),
                'longitude' => floatval($a['longitude_deg'] ?? 0),
                'iso2' => $iso2,
                'country_name' => $country_map[$iso2] ?? ''
            ], ['%s','%s','%s','%s','%f','%f','%s','%s'] );
        }
    }
    private function parse_csv( $file ) {
        $rows = [];
        if ( ! file_exists($file) ) return $rows;
        if ( ($handle = fopen($file,'r')) !== false ) {
            $header = null;
            while ( ($data = fgetcsv($handle)) !== false ) {
                if ( !$header ) {
                    $header = $data;
                    continue;
                }
                if ( count($header) === count($data) ) {
                    $rows[] = array_combine($header,$data);
                }
            }
            fclose($handle);
        }
        return $rows;
    }
    public function register_routes() {
        register_rest_route('wd-flight/v1','/airports',[
            'methods' => 'GET',
            'callback' => [$this,'get_airports'],
            'permission_callback' => '__return_true'
        ]);
    }
    public function get_airports( $request ) {
        global $wpdb;
        $q = trim( mb_strtolower( sanitize_text_field( $request->get_param('q') ) ) );
        if ( strlen($q) < 2 ) return [];
        $airports_table = $wpdb->prefix . 'wd_airports';
        $sql = $wpdb->prepare("
            SELECT name,city,iata_code,icao_code,iso2,country_name 
            FROM $airports_table
            WHERE icao_code IS NOT NULL AND icao_code != ''
              AND (
                  LOWER(name) LIKE %s OR
                  LOWER(city) LIKE %s OR
                  LOWER(iata_code) LIKE %s OR
                  LOWER(icao_code) LIKE %s OR
                  LOWER(country_name) LIKE %s OR
                  LOWER(iso2) LIKE %s
              )
            ORDER BY CONCAT(country_name, city) ASC
            LIMIT 200
        ",
        "%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%"
        );
        $rows = $wpdb->get_results( $sql, ARRAY_A );
        if ( !$rows ) return [];
        $grouped = [];
        foreach ( $rows as $a ) {
            $iso2 = strtolower($a['iso2'] ?: 'xx');
            $country_name = $a['country_name'] ?: 'Other airports';
            if ( stripos($country_name,'unknown') !== false || stripos($country_name,'unassigned') !== false ) {
                $iso2 = 'xx';
                $country_name = 'Other airports';
            }
            if ( !isset($grouped[$iso2]) ) {
                $grouped[$iso2] = [
                    'country_name' => $country_name,
                    'iso2' => $iso2,
                    'airports' => []
                ];
            }
            $grouped[$iso2]['airports'][] = [
                'name' => $a['name'],
                'city' => $a['city'],
                'iata_code' => $a['iata_code'],
                'icao_code' => $a['icao_code']
            ];
        }
        return array_values($grouped);
    }
    public function render_search_shortcode() {
        return '<div id="wd-search-flight"></div>';
    }
}
