=== WD Flight Reservation ===
Contributors: websdaddy
Tags: flight, booking, search, airports, multi-leg
Requires at least: 5.0
Tested up to: 6.9
Stable tag: 1.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Freemium WordPress plugin for flight search and reservations. Upgrade to PRO for multi-leg flight searches.

== Description ==

WD Flight Reservation is a **freemium flight search plugin** for WordPress.  
Easily add a flight search form with airport auto-complete, date selection, and passenger input to your site.

**Free Version Features:**
* Single-leg flight search
* Airport auto-complete powered by REST API
* Flatpickr date picker
* Responsive and mobile-friendly design

**PRO Version Features (Upgrade for $49 one-time fee):**
* Multi-leg flight search (up to 6 legs)
* Passenger and special requirements support
* Enhanced UI with Vue.js
* Priority support and updates

**Why Choose WD Flight Reservation PRO?**
- Simple integration via shortcode `[wd-flight-search]`
- Modern, responsive design
- Quick search with auto-complete airports
- Easy upgrade from free to PRO for advanced features

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/wd-flight-reservation` directory, or install via the WordPress plugins screen.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Add the shortcode `[wd-flight-search]` to any page or post where you want the flight search form to appear.
4. For PRO features, purchase the PRO version and replace the free plugin files with the PRO version files.

== Frequently Asked Questions ==

= How do I add the flight search form to a page? =
Use the shortcode `[wd-flight-search]` on any page or post.

= Can I search for multi-leg flights in the free version? =
No. Multi-leg flight search is only available in the PRO version.

= What payment methods are accepted for PRO upgrade? =
You can purchase the PRO version via Stripe with a $49 one-time fee.

= Does the plugin support mobile devices? =
Yes. The search form and all features are fully responsive.

== Screenshots ==

1. `preview.png` – Screenshot of the PRO flight search form (1024x269px)
2. Free version search form layout
3. PRO version multi-leg search form
4. Passenger & special requirements fields (PRO)
5. Date picker with Flatpickr
6. Airport auto-complete dropdown

== Changelog ==

= 1.3 =
* Added Vue.js multi-leg support for PRO version
* Updated styling and responsive improvements
* Added passenger & special requirements support

= 1.2 =
* Fixed airport search ordering
* Minor UI enhancements

= 1.0 =
* Initial release

== Upgrade Notice ==

= 1.3 =
Upgrade to PRO to unlock **multi-leg flight search** and additional advanced features.

== Additional Notes ==

* All included libraries and assets are GPL compatible.
* Tested with the latest WordPress version up to 6.5.
